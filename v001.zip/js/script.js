
// On Load
window.addEventListener("DOMContentLoaded", () => {
    document.querySelectorAll(".card").forEach(card => {
        card.addEventListener("click", handleLClick);
        card.addEventListener("mouseenter", hoverOn);
        card.addEventListener("mouseleave", hoverOff);
    });
});

function hoverOn(event) {
    
}

function hoverOff(event) {
    
}